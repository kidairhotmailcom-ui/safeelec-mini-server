/*
  SAFE-ELEC V4.2 — ADAPTIVE HARDWARE BASELINE
  Target: ESP32 DevKit V1
  Status: PROVISIONAL BASELINE for Wokwi + later real-device adaptation.

  IMPORTANT HARDWARE FINDINGS:
  - GPIO34 is INPUT ONLY: cannot drive 74HC595 SER/data.
  - GPIO6..GPIO11 are normally connected to ESP32 flash: do not use for selector.
  - GPIO1 is UART TX; GPIO7 is flash-connected on typical DevKit V1.
  - GPIO23 is also default VSPI MOSI; avoid sharing it with a sensor if using default SPI SD.
  This baseline uses safer provisional pins for 74HC595 and selector. Recheck against
  the exact ESP32 board and modules before real wiring.

  This firmware only issues low-voltage control commands to a selector/interface.
  It is NOT a mains power disconnect device. Use certified protection hardware and
  an appropriately designed electrical installation.
*/

#include <Arduino.h>
#include <Wire.h>
#include <WiFi.h>
#include <WebServer.h>
#include <ArduinoOTA.h>
#include <U8g2lib.h>
#include <DHT.h>
#include <OneWire.h>
#include <DallasTemperature.h>
#include <SPI.h>
#include <SD.h>

// ================= USER CONFIGURATION =================
// Network: Wokwi simulation defaults; change for real installation.
static const char* WIFI_SSID = "Wokwi-GUEST";
static const char* WIFI_PASS = "";

// Device identity for status page / OTA
static const char* DEVICE_NAME = "SAFE-ELEC-V4-2";
static const char* OTA_PASSWORD = "CHANGE_THIS_OTA_PASSWORD";

// Safe behavior: leave command outputs inactive until system checks complete.
// Set true only after verifying output polarity and selector interface.
static const bool ENABLE_SELECTOR_COMMANDS = false;
static const bool RELAY_ACTIVE_LOW = true;
static const bool SR_OUTPUT_ACTIVE_HIGH = true;

// Provisional corrected pins. Adjust after checking exact hardware.
constexpr uint8_t PIN_I2C_SDA = 21;
constexpr uint8_t PIN_I2C_SCL = 22;
constexpr uint8_t PIN_SR_DATA  = 17; // GPIO34 is input-only; cannot be used here
constexpr uint8_t PIN_SR_CLOCK = 33;
constexpr uint8_t PIN_SR_LATCH = 2;
constexpr uint8_t PIN_DHT      = 15;
constexpr uint8_t PIN_ONEWIRE  = 4;
constexpr uint8_t PIN_PIR      = 27;
constexpr uint8_t PIN_STOP     = 14;
constexpr uint8_t PIN_BUZZER   = 25; // provisional; avoid GPIO6
constexpr uint8_t PIN_STATUS_LED = 26;
constexpr uint8_t PIN_SELECTOR = 16; // provisional; GPIO6 is flash-connected

// Legacy zone relay pins from supplied mapping; GPIOs 18/19/5/12/13/16 need
// module-specific polarity/boot-state checks before any live load is connected.
constexpr uint8_t RELAY_PINS[6] = {12, 13, 19, 18, 16, 5};

// Optional SD card: default VSPI pins are 18/19/23/5, which conflict with some
// legacy assignments above. SD is therefore DISABLED until a dedicated SPI map
// and chip-select are confirmed.
static const bool ENABLE_SD = false;
constexpr uint8_t PIN_SD_CS = 5;

// Thermal thresholds (°C); use only after validating sensor placement/calibration.
constexpr float TEMP_WARN_C = 50.0f;
constexpr float TEMP_ALARM_C = 65.0f;
constexpr float TEMP_CUT_C = 80.0f;
constexpr uint32_t SENSOR_SAMPLE_MS = 2000;
constexpr uint32_t PIR_HOLD_MS = 30000;
constexpr uint32_t SELECTOR_DEADTIME_MS = 1500;
constexpr uint32_t WIFI_RETRY_MS = 15000;

// 74HC595 chain mapping from the supplied description.
// SR2 = first register, SR3 = second register; verify physical chain order.
enum SR2Bit : uint8_t {
  SR2_FAN = 0, SR2_RESERVED_1 = 1, SR2_ALERT_LED = 2, SR2_SENSOR_LED = 3,
  SR2_CUT_OUT_1 = 4, SR2_CUT_OUT_2 = 5, SR2_CUT_OUT_3 = 6, SR2_RESERVED_7 = 7
};
enum SR3Bit : uint8_t {
  SR3_RESERVED_0 = 0, SR3_AUTO_CUT = 1, SR3_BUZZER = 2, SR3_SYSTEM_LED = 3,
  SR3_RESERVED_4 = 4, SR3_RESERVED_5 = 5, SR3_MAIN_BACKUP = 6, SR3_HEARTBEAT = 7
};

// ================= OBJECTS =================
U8G2_SSD1306_128X64_NONAME_F_HW_I2C oled(U8G2_R0, U8X8_PIN_NONE);
DHT dht(PIN_DHT, DHT22);
OneWire oneWire(PIN_ONEWIRE);
DallasTemperature ds18b20(&oneWire);
WebServer server(80);

// ================= STATE =================
uint8_t sr2State = 0;
uint8_t sr3State = 0;
float dhtTempC = NAN, humidity = NAN, dsTempC = NAN;
bool dhtOK = false, dsOK = false, pirDetected = false;
bool wifiOK = false, oledOK = false, sdOK = false;
bool stopPressed = false, thermalAlarm = false, thermalCutRequest = false;
bool systemReady = false, commandMode = false;
uint32_t lastSensorMs = 0, lastPirMs = 0, lastWifiRetryMs = 0;
uint32_t lastHeartbeatMs = 0, lastDisplayMs = 0;
uint32_t lastSelectorChangeMs = 0;
String lastFault = "Booting";
String i2cDevices = "";
String dsAddressList = "";
String activeProfile = "SAFE / OUTPUTS DISABLED";

// ================= LOW-LEVEL HELPERS =================
void setSRBit(uint8_t &value, uint8_t bit, bool on) {
  if (on) value |= (uint8_t)(1U << bit);
  else value &= (uint8_t)~(1U << bit);
}

void writeShiftRegisters() {
  uint8_t a = sr2State, b = sr3State;
  if (!SR_OUTPUT_ACTIVE_HIGH) { a = ~a; b = ~b; }
  digitalWrite(PIN_SR_LATCH, LOW);
  // Shift order depends on physical cascade direction. Verify SR2/SR3 on bench.
  shiftOut(PIN_SR_DATA, PIN_SR_CLOCK, MSBFIRST, b);
  shiftOut(PIN_SR_DATA, PIN_SR_CLOCK, MSBFIRST, a);
  digitalWrite(PIN_SR_LATCH, HIGH);
}

void setRelay(uint8_t index, bool on) {
  if (index >= 6) return;
  digitalWrite(RELAY_PINS[index], (on ^ RELAY_ACTIVE_LOW) ? HIGH : LOW);
}

void allRelayCommandsOff() {
  for (uint8_t i = 0; i < 6; i++) setRelay(i, false);
  digitalWrite(PIN_SELECTOR, LOW);
  sr2State = 0;
  sr3State = 0;
  writeShiftRegisters();
}

void safeShutdownCommands(const char* reason) {
  allRelayCommandsOff();
  thermalCutRequest = true;
  commandMode = false;
  lastFault = reason;
  digitalWrite(PIN_STATUS_LED, LOW);
  // Intentionally does not energize any selector/cut output on a fault.
}

String tempText(float v) {
  if (isnan(v)) return "N/A";
  return String(v, 1) + " C";
}

// ================= HARDWARE DISCOVERY =================
void scanI2C() {
  i2cDevices = "";
  uint8_t found = 0;
  for (uint8_t address = 1; address < 127; address++) {
    Wire.beginTransmission(address);
    if (Wire.endTransmission() == 0) {
      if (i2cDevices.length()) i2cDevices += ", ";
      char buf[8];
      snprintf(buf, sizeof(buf), "0x%02X", address);
      i2cDevices += buf;
      found++;
    }
  }
  if (!found) i2cDevices = "none";
}

void scanOneWireDevices() {
  dsAddressList = "";
  DeviceAddress addr;
  uint8_t count = ds18b20.getDeviceCount();
  for (uint8_t i = 0; i < count; i++) {
    if (ds18b20.getAddress(addr, i)) {
      if (dsAddressList.length()) dsAddressList += "; ";
      char buf[24];
      snprintf(buf, sizeof(buf), "%02X-%02X-%02X-%02X-%02X-%02X-%02X-%02X",
        addr[0],addr[1],addr[2],addr[3],addr[4],addr[5],addr[6],addr[7]);
      dsAddressList += buf;
    }
  }
  if (!count) dsAddressList = "none";
}

// Device discovery is limited to interfaces that support identification.
// DHT22/PIR/relay modules generally do not expose a universal model ID.
void discoverHardware() {
  scanI2C();
  scanOneWireDevices();
  oled.clearBuffer();
  oled.setFont(u8g2_font_6x10_tf);
  oled.drawStr(0, 12, "SAFE-ELEC HW scan");
  oled.drawStr(0, 28, oledOK ? "OLED: started" : "OLED: not confirmed");
  oled.drawStr(0, 42, "I2C scan done");
  oled.drawStr(0, 56, "See web/serial report");
  oled.sendBuffer();
  Serial.println("\n=== SAFE-ELEC HARDWARE DISCOVERY ===");
  Serial.printf("I2C devices: %s\n", i2cDevices.c_str());
  Serial.printf("DS18B20 count: %u; ROMs: %s\n", ds18b20.getDeviceCount(), dsAddressList.c_str());
  Serial.println("DHT22/PIR/relay/74HC595: no universal model-ID scan; verify by test/calibration.");
}

// ================= SENSORS / LOGIC =================
void sampleSensors() {
  dhtTempC = dht.readTemperature();
  humidity = dht.readHumidity();
  dhtOK = !isnan(dhtTempC) && !isnan(humidity);

  ds18b20.requestTemperatures();
  dsTempC = ds18b20.getTempCByIndex(0);
  dsOK = dsTempC != DEVICE_DISCONNECTED_C && dsTempC > -55 && dsTempC < 125;

  if (!dhtOK && !dsOK) {
    lastFault = "Both temperature sensors unavailable";
  } else if (!dhtOK) {
    lastFault = "DHT22 read failed";
  } else if (!dsOK) {
    lastFault = "DS18B20 read failed";
  } else {
    lastFault = "None";
  }

  // Use the highest valid measured temperature for conservative warning logic.
  float maxTemp = -1000;
  if (dhtOK) maxTemp = max(maxTemp, dhtTempC);
  if (dsOK) maxTemp = max(maxTemp, dsTempC);

  thermalAlarm = maxTemp >= TEMP_ALARM_C;
  thermalCutRequest = maxTemp >= TEMP_CUT_C;

  setSRBit(sr2State, SR2_ALERT_LED, maxTemp >= TEMP_WARN_C);
  setSRBit(sr2State, SR2_SENSOR_LED, dhtOK || dsOK);
  setSRBit(sr3State, SR3_BUZZER, thermalAlarm || thermalCutRequest);
  setSRBit(sr3State, SR3_SYSTEM_LED, true);
  writeShiftRegisters();

  if (thermalCutRequest) {
    // Do not automatically switch live power here. A verified selector interface
    // and the final interlock logic must be configured first.
    lastFault = "TEMP CUT THRESHOLD reached; command inhibited";
    commandMode = false;
  }
}

void updatePIR() {
  pirDetected = digitalRead(PIN_PIR) == HIGH;
  if (pirDetected) lastPirMs = millis();
  // PIR auto-off is represented as status only until the target output mapping
  // and selector interface are validated.
  bool recentlyOccupied = (millis() - lastPirMs) < PIR_HOLD_MS;
  setSRBit(sr3State, SR3_AUTO_CUT, !recentlyOccupied);
}

void handleStopButton() {
  stopPressed = digitalRead(PIN_STOP) == LOW; // INPUT_PULLUP
  if (stopPressed) {
    allRelayCommandsOff();
    commandMode = false;
    lastFault = "STOP button pressed";
  }
}

void updateHeartbeat() {
  if (millis() - lastHeartbeatMs >= 1000) {
    lastHeartbeatMs = millis();
    static bool heartbeat = false;
    heartbeat = !heartbeat;
    setSRBit(sr3State, SR3_HEARTBEAT, heartbeat);
    digitalWrite(PIN_STATUS_LED, heartbeat ? HIGH : LOW);
    writeShiftRegisters();
  }
}

// ================= WEB STATUS / OTA =================
String statusJson() {
  String s = "{";
  s += "\"device\":\"" + String(DEVICE_NAME) + "\",";
  s += "\"wifi\":" + String(wifiOK ? "true" : "false") + ",";
  s += "\"ip\":\"" + (wifiOK ? WiFi.localIP().toString() : String("offline")) + "\",";
  s += "\"dht_ok\":" + String(dhtOK ? "true" : "false") + ",";
  s += "\"dht_temp_c\":" + (isnan(dhtTempC) ? String("null") : String(dhtTempC, 1)) + ",";
  s += "\"humidity\":" + (isnan(humidity) ? String("null") : String(humidity, 1)) + ",";
  s += "\"ds18b20_ok\":" + String(dsOK ? "true" : "false") + ",";
  s += "\"ds18b20_temp_c\":" + (isnan(dsTempC) ? String("null") : String(dsTempC, 1)) + ",";
  s += "\"pir\":" + String(pirDetected ? "true" : "false") + ",";
  s += "\"thermal_alarm\":" + String(thermalAlarm ? "true" : "false") + ",";
  s += "\"thermal_cut_request\":" + String(thermalCutRequest ? "true" : "false") + ",";
  s += "\"i2c\":\"" + i2cDevices + "\",";
  s += "\"ds18b20_roms\":\"" + dsAddressList + "\",";
  s += "\"fault\":\"" + lastFault + "\",";
  s += "\"command_mode\":\"" + activeProfile + "\"}";
  return s;
}

void setupWeb() {
  server.on("/", HTTP_GET, []() {
    String page = "<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'>";
    page += "<meta http-equiv='refresh' content='5'><title>SAFE-ELEC</title></head><body>";
    page += "<h2>SAFE-ELEC V4.2 — Hardware status</h2><pre>";
    page += statusJson();
    page += "</pre><p>Selector commands: ";
    page += ENABLE_SELECTOR_COMMANDS ? "CONFIGURED ENABLE" : "DISABLED (safe default)";
    page += "</p><p>Use /scan to rescan supported buses. No high-voltage control.</p></body></html>";
    server.send(200, "text/html; charset=utf-8", page);
  });
  server.on("/status", HTTP_GET, []() { server.send(200, "application/json", statusJson()); });
  server.on("/scan", HTTP_GET, []() {
    discoverHardware();
    server.send(200, "application/json", statusJson());
  });
  server.on("/command/enable", HTTP_POST, []() {
    if (!ENABLE_SELECTOR_COMMANDS) {
      server.send(403, "text/plain", "Disabled in firmware configuration");
      return;
    }
    if (stopPressed || thermalCutRequest || (!dhtOK && !dsOK)) {
      server.send(409, "text/plain", "Interlock: command rejected");
      return;
    }
    if (millis() - lastSelectorChangeMs < SELECTOR_DEADTIME_MS) {
      server.send(429, "text/plain", "Selector deadtime");
      return;
    }
    // This is only a low-voltage command to the selector interface.
    digitalWrite(PIN_SELECTOR, HIGH);
    lastSelectorChangeMs = millis();
    commandMode = true;
    server.send(200, "text/plain", "Selector command issued");
  });
  server.on("/command/disable", HTTP_POST, []() {
    digitalWrite(PIN_SELECTOR, LOW);
    commandMode = false;
    lastSelectorChangeMs = millis();
    server.send(200, "text/plain", "Selector command deasserted");
  });
  server.begin();
}

void connectNetwork() {
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASS);
  uint32_t start = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - start < 8000) delay(250);
  wifiOK = WiFi.status() == WL_CONNECTED;
  if (wifiOK) {
    ArduinoOTA.setHostname(DEVICE_NAME);
    ArduinoOTA.setPassword(OTA_PASSWORD);
    ArduinoOTA.begin();
    setupWeb();
    Serial.printf("Wi-Fi IP: %s\n", WiFi.localIP().toString().c_str());
  } else {
    Serial.println("Wi-Fi offline; local safety logic continues.");
  }
}

// ================= SETUP / LOOP =================
void setup() {
  Serial.begin(115200);
  delay(200);
  Serial.println("\nSAFE-ELEC V4.2 Adaptive Hardware Baseline");

  pinMode(PIN_SR_DATA, OUTPUT);
  pinMode(PIN_SR_CLOCK, OUTPUT);
  pinMode(PIN_SR_LATCH, OUTPUT);
  digitalWrite(PIN_SR_DATA, LOW);
  digitalWrite(PIN_SR_CLOCK, LOW);
  digitalWrite(PIN_SR_LATCH, LOW);

  for (uint8_t i = 0; i < 6; i++) {
    pinMode(RELAY_PINS[i], OUTPUT);
    setRelay(i, false);
  }
  pinMode(PIN_SELECTOR, OUTPUT);
  digitalWrite(PIN_SELECTOR, LOW);
  pinMode(PIN_STOP, INPUT_PULLUP);
  pinMode(PIN_PIR, INPUT);
  pinMode(PIN_STATUS_LED, OUTPUT);
  pinMode(PIN_BUZZER, OUTPUT);
  digitalWrite(PIN_BUZZER, LOW);

  Wire.begin(PIN_I2C_SDA, PIN_I2C_SCL);
  oled.begin();
  oledOK = true;
  dht.begin();
  ds18b20.begin();

  allRelayCommandsOff();
  connectNetwork();

  discoverHardware();
  sampleSensors();
  systemReady = true;
  Serial.println("Ready: safe baseline; selector commands remain disabled unless configured.");
}

void loop() {
  if (wifiOK) {
    ArduinoOTA.handle();
    server.handleClient();
    if (WiFi.status() != WL_CONNECTED) wifiOK = false;
  } else if (millis() - lastWifiRetryMs >= WIFI_RETRY_MS) {
    lastWifiRetryMs = millis();
    if (WiFi.status() != WL_CONNECTED) {
      WiFi.disconnect();
      WiFi.begin(WIFI_SSID, WIFI_PASS);
    } else {
      wifiOK = true;
      setupWeb();
      ArduinoOTA.setHostname(DEVICE_NAME);
      ArduinoOTA.setPassword(OTA_PASSWORD);
      ArduinoOTA.begin();
    }
  }

  if (millis() - lastSensorMs >= SENSOR_SAMPLE_MS) {
    lastSensorMs = millis();
    sampleSensors();
    updatePIR();
    handleStopButton();
    writeShiftRegisters();
  }

  updateHeartbeat();

  if (millis() - lastDisplayMs >= 1000) {
    lastDisplayMs = millis();
    oled.clearBuffer();
    oled.setFont(u8g2_font_6x10_tf);
    oled.drawStr(0, 10, "SAFE-ELEC V4.2");
    String t1 = "DHT: " + tempText(dhtTempC);
    String t2 = "DS18: " + tempText(dsTempC);
    String t3 = String("PIR: ") + (pirDetected ? "DETECTED" : "clear");
    String t4 = thermalCutRequest ? "TEMP CUT: REQUEST" : (thermalAlarm ? "TEMP: ALARM" : "TEMP: normal");
    oled.drawStr(0, 22, t1.c_str());
    oled.drawStr(0, 33, t2.c_str());
    oled.drawStr(0, 44, t3.c_str());
    oled.drawStr(0, 55, t4.c_str());
    oled.sendBuffer();
  }
}
