SAFE-ELEC V4.2 — Adaptive Hardware Baseline

Included:
- SAFE_ELEC_V4_2_ADAPTIVE.ino
- This README

Target:
- ESP32 DevKit V1
- Two chained 74HC595 shift registers
- SSD1306 OLED (I2C)
- DHT22, DS18B20, PIR, stop button
- Optional SD card disabled by default
- Wi-Fi status page, I2C scan, DS18B20 ROM scan, OTA hooks

Libraries required in Arduino IDE / Wokwi:
- U8g2
- DHT sensor library (Adafruit)
- OneWire
- DallasTemperature

Important:
1. This is an adaptive baseline, not a verified build of the user's complete original V4.2 source.
2. Selector commands are disabled by default (ENABLE_SELECTOR_COMMANDS=false).
3. Do not connect mains/high-power loads to ESP32 pins or shift-register outputs.
4. GPIO34 cannot be an output. GPIO6-11 are normally reserved for flash. This file uses
   GPIO17 for 74HC595 data and GPIO16 for the selector command as provisional corrections.
5. The relay mapping and active polarity must be confirmed against the actual relay board.
6. SD is disabled because the legacy relay assignments conflict with default VSPI pins.
7. DHT22, PIR, relays, and most 74HC595 outputs cannot reveal their exact model/function
   automatically. The firmware scans only discoverable buses and reports sensor failures.
8. The web /scan endpoint re-scans I2C and 1-Wire devices. OTA works only after a first
   firmware has already been flashed and Wi-Fi access is configured.
9. Test in simulation and with low-voltage indicator loads first. Do not use this baseline
   to switch real electrical power until a qualified person verifies wiring/interlocks.
